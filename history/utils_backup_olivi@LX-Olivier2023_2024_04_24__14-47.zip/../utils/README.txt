# Directory for small utilities
# backup, maintenance, synchronization
# INRAE\Olivier Vitrac - 2022

note: Previous Octave/Matlab files used for post-treatment moved to post/
