# Data Directory for Pizza3

This directory is intended to store datasets and auxiliary files required for running simulations or examples in Pizza3.

## Usage
- Place simulation input data or preprocessed files here.
- Keep the directory organized by creating subdirectories if needed.

## Notes
- Ensure that any sensitive or proprietary data is excluded from version control by adding it to `.gitignore`.
