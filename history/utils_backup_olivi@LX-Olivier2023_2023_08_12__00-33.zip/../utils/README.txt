# Directory for small utilities
# backup, maintenance, synchronization
# INRAE\Olivier Vitrac - 2022