# Directory for small utilities
# backup, maintenance, synchronization
# INRAE\Olivier Vitrac - 2024

Use ./generate_diagrams.sh to generate the inheritance tree for all classes in pizza/.
Use ./generate_all to refresh all metadata __all__
Use ./pdocme to regenerate the entire documentation in HTML
Use ./create_default_manifest to generate the manifest