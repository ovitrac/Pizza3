#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__project__ = "Pizza3"
__author__ = "Olivier Vitrac, Han Chen"
__copyright__ = "Copyright 2023"
__credits__ = ["Olivier Vitrac","Han Chen"]
__license__ = "GPLv3"
__maintainer__ = "Olivier Vitrac"
__email__ = "olivier.vitrac@agroparistech.fr"
__version__ = "0.50"

"""
    REGION provide tools to define native geometries in Python for LAMMPS

"""


# INRAE\Olivier Vitrac - rev. 2023-01-11
# contact: olivier.vitrac@agroparistech.fr, han.chen@inrae.fr

# Revision history
# 2023-01-04 code initialization
# 2023-01-10 early alpha version
# 2023-01-11 alpha version (many fixes), wrap and align all displays with textwrap.fill, textwrap.shorten
# 2023-01-12 implement methods of keyword(units/rotate/open)

# %% Imports and private library
import os
from copy import copy as duplicate
from copy import deepcopy as deepduplicate
from textwrap import fill, shorten
# import struct, param, paramauto
from pizza.private.struct import *
from pizza.script import script, scriptdata, span

# %% Low level functions
# wrap and indent text for variables
wrap = lambda k,op,v,indent,width,maxwidth: fill(
        shorten(v,width=maxwidth+indent,
        fix_sentence_endings=True),
        width=width+indent,
        initial_indent=" "*(indent-len(k)-len(op)-2)+f'{k} {op} ',
        subsequent_indent=' '*(indent+(1 if v[0]=='"' else 0) )
        )

# %% Top generic classes for storing region data and objects
# they are not intended to be used outside script data and objects

class regiondata(paramauto):
    """
        class of script parameters
            Typical constructor:
                DEFINITIONS = regiondata(
                    var1 = value1,
                    var2 = value2
                    )
        See script, struct, param to get review all methods attached to it
    """
    _type = "RD"
    _fulltype = "region data"
    _ftype = "definition"

    def generatorforlammps(self):
        """ generate LAMMPS code from regiondata (struct) """
        nk = len(self)
        if nk>0:
            self.sortdefinitions(raiseerror=False)
            s = self.tostruct()
            ik = 0
            fmt = "variable %s equal %s"
            cmd = f"# Definition of {nk} variables\n"
            for k in s.keys():
                ik += 1
                end = "\n" if ik<nk else "\n"*2
                v = getattr(s,k)
                if v is None: v = "NULL"
                if isinstance(v,(int,float)) or v == None:
                    cmd += fmt % (k,v)+end
                elif isinstance(v,str):
                    cmd += fmt % (k,f'{v}')+end
                elif isinstance(v,(list,tuple)):
                    cmd += fmt % (k,span(v))+end
                else:
                    raise ValueError(f"unsupported type for the variable {k} set to {v}")
        return cmd

# %% PRIVATE SUB-CLASSES
# Use the equivalent methods of raster() to call these constructors
class genericregion(script):
    """ generic region based on script """
    SECTIONS = ["VARIABLES","REGION","CREATE"]
    position = None
    role = "region command definition"
    description = "region ID style args keyword arg"
    userid = "generic region"               # user name
    version = 1.0                           # version
    verbose = True

    # SMD Scheme (these variables are available everywhere)
    DEFINITIONS = scriptdata(
                    ID = "${ID}",
                 style = "${style}",
                  args = "${args}",
                  side = "${side}",
                 units = "${units}",
                  move = "${move}",
                rotate = "${rotate}",
                  open = "${open}",
                    )

    # Template
    #TEMPLATE = "\n\n# " + "\n# ".join(script._contact) + "\n"*3 + """
    TEMPLATE = "\n" + """
# please read: https://docs.lammps.org/region.html
# List of keywords: side, units, move, rotate, open
# Possible argument values:
#    in|out, lattice|box, v_x v_y v_z, v_theta Px Py Pz Rx Ry Rz, integer

region ${ID} ${style} ${args} ${side}${units}${move}${rotate}${open}
create_atoms ${beadtype} region ${ID}
 """

    def do(self,printflag=True):
        """
            generate the LAMMPS code with VARIABLE definitions if needed
            extend the dp method available with script
        """
        # old dowithVARIABLES
        cmd = self.VARIABLES.generatorforlammps() if len(self.VARIABLES)>0 else ""
        cmd += super().do(printflag=False) # script.do()
        if printflag: print(cmd)
        return cmd

class coregeometry:
    """
        core geometry object
        (helper class for attributes, side,units, move, rotate, open)
    """

    def __repr__(self):
        """ display method"""
        nVAR = len(self.VARIABLES)
        print("%s - %s object - beadtype=%d " % (self.name, self.kind,self.beadtype))
        if hasattr(self,"filename"): print(f'\tfilename: "{self.filename}"')
        if nVAR>0:
            print(f"\t<-- {nVAR} variables are defined -->")
            print(f"\tUse {self.name}.VARIABLES to see details and their evaluation")
            for k,v in self.VARIABLES.items():
                v0 = '"'+v+'"' if isinstance(v,str) else repr(v)
                print(wrap(k,"=",v0,20,40,80))
        print("\t<-- keyword arg -->")
        haskeys = False
        for k in ("side","move","units","rotate","open"):
            if k in self.USER:
                v = self.USER.getattr(k)
                if v != "":
                    print(wrap(k,":",v[1:],20,60,80))
                    haskeys = True
        if not haskeys: print(wrap("no keywords","<","from side|move|units|rotate|open",20,60,80))
        return "%s object: %s (beadtype=%d)" % (self.kind,self.name,self.beadtype)


    def sidearg(self,side):
        """ validator of side arguments """
        prefix = "$"
        if side is None:
            return ""
        elif isinstance(side, str):
            side = side.lower()
            if side in ("in","out"):
                return f"{prefix} side {side}"
            elif (side=="") or (side=="none"):
                return ""
            else:
                raise ValueError(f'the value of sihde: "{side}" is not recognized')
        else:
            raise ValueError('the parameter side can be "in|out|None"')

    def movearg(self,move):
        """ validator of move arguments """
        prefix = "$"
        if move is None:
            return ""
        elif isinstance(move, str):
            move = move.lower()
            if (move=="") or (move=="none"):
                return ""
            else:
                return f" move {move}"
        elif isinstance(move,(list,tuple)):
            if len(move)<3:
                print("NULL will be added to move")
            elif len(move)>3:
                print("move will be truncated to 3 elements")
            movevalid = ["NULL","NULL","NULL"]
            for i in range(min(3,len(move))):
                if isinstance(move[i],str):
                    if move[i].upper()!="NULL":
                        if prefix in move[i]:
                            # we assume a numeric result after evaluation
                            # Pizza variables will be evaluated
                            # formateval for the evaluation of ${}
                            # eval for residual expressions
                            movevalid[i] = round(eval(self.VARIABLES.formateval(move[i])),6)
                        else:
                            # we assume a variable (LAMMPS variable, not Pizza ones)
                            movevalid[i] = "v_" + move[i]
                elif not isinstance(move[i],(int,float)):
                    if (move[i] is not None):
                        raise ValueError("move values should be str, int or float")
            return f"{prefix} move {span(movevalid)}"
        else:
            raise ValueError("the parameter move should be a list or tuple")

    def units(self,units):
        """ Validation for units arguments """
        if units is None:
            return ""
        elif isinstance(units,str):
            units = units.lower()
            if units in ("lattice","box"):
                return f" units {units}"
            elif (units=="") or (units=="none"):
                return ""
            else:
                raise ValueError(f'the value of side: "{units}" is not recognized')
        else:
            raise ValueError('the parameter units can be "lattice|box|None"')
            
    def rotatearg(self,rotate):
        """ validator of rotate arguments """
        prefix = "$"
        if rotate is None:
            return ""
        elif isinstance(rotate, str):
            rotate = rotate.lower()
            if (rotate=="") or (rotate=="none"):
                return ""
            else:
                return f" rotate {rotate}"
        elif isinstance(rotate,(list,tuple)):
            if len(rotate)<7:
                print("NULL will be added to rotate")
            elif len(rotate)>7:
                print("rotate will be truncated to 7 elements")
            rotatevalid = ["NULL","NULL","NULL","NULL","NULL","NULL","NULL"]
            for i in range(min(7,len(rotate))):
                if isinstance(rotate[i],str):
                    if rotate[i].upper()!="NULL":
                        if prefix in rotate[i]:
                            rotatevalid[i] = round(eval(self.VARIABLES.formateval(rotate[i])),6)
                        else:
                            rotatevalid[i] = rotate[i]
                elif not isinstance(rotate[i],(int,float)):
                    if (rotate[i] is not None):
                        raise ValueError("rotate values should be str, int or float")
            return f"{prefix} move {span(rotatevalid)}"
        else:
            raise ValueError("the parameter rotate should be a list or tuple")
            
    def openarg(self,open):
        """ Validation for open arguments """ 
        if open is None:
            return ""
        elif isinstance(open, str):
            raise ValueError(" the parameter open should be an integer or a list/tuple of integers from 1-6")
        elif isinstance(open, int):
            if open in range(1,7):
                return f" open {open}"
            else:
                raise ValueError(" open value shoulf be integer from 1-6")
        elif isinstance(open, (list,tuple)):
            openvalid = [f" open {i}" for i in range(1,7) if i in open]
            return f"$ {span(openvalid)}"

class Ellipsoid(coregeometry,genericregion):
    """ Ellipsoid class """

    def __init__(self,counter,index=None,subindex=None,**variables):
        self.index = counter[0]
        self.name = "ellipsoid%03d" % counter[1]
        self.kind = "ellipsoid"      # kind of object
        self.alike = "ellipsoid"     # similar object for plotting
        self.beadtype = 1            # bead type
        self.index = index
        self.subindex = subindex
        self.USER = regiondata(style="$ellipsoid")
        self.VARIABLES = regiondata(**variables)

    def __repr__(self):
        return super(Ellipsoid,self).__repr__()


# %% region class (main class)
class region:
    """
        region main class
    """
    _version = "0.01"

    # CONSTRUCTOR ----------------------------
    def __init__(self,
                 # raster properties
                 name="default region",
                 # for data conversion
                 mass=1,
                 volume=1,
                 radius=1.5,
                 contactradius=0.5,
                 velocities=[0,0,0],
                 forces=[0,0,0],
                 filename="",
                 index = None
                 ):
        """ constructor """
        self.name = name
        # generic SMD properties (to be rescaled)
        self.volume = volume
        self.mass = mass
        self.radius = radius
        self.contactradius = contactradius
        self.velocities = velocities
        self.forces =forces
        if filename == "":
            self.filename = "region (%s)" % self.name
        else:
            self.filename = filename
        self.index = index
        self.objects = {}    # object container
        self.nobjects = 0    # total number of objects (alive)
        # count objects per type
        self.counter = { "ellipsoid":0,
                              "all":0
                    }

    # DISP method ----------------------------
    def __repr__(self):
        """ display method """
        print("-"*40)
        print('REGION container "%s" with %d objects' % (self.name,self.nobjects))
        if self.nobjects>0:
            print(wrap("they are",":",", ".join(R.names()),10,60,80))
        print("-"*40)
        return "REGION container %s" % self.name

    # LIST method ----------------------------
    def list(self):
        """ list objects """
        fmt = "%%%ss:" % max(10,max([len(n) for n in self.names()])+2)
        print('REGION container "%s" with %d objects' % (self.name,self.nobjects))
        for o in self.objects.keys():
            print(fmt % self.objects[o].name,"%-10s" % self.objects[o].kind,
                  "(beadtype=%d,object index=[%d,%d])" % \
                      (self.objects[o].beadtype,
                       self.objects[o].index,
                       self.objects[o].subindex))

    # ELLIPSOID method ---------------------------
    def ellipsoid(self,x,y,z,a,b,c,
                  name=None,beadtype=None,fake=False,
                  side=None,units=None,move=None,rotate=None,open=None,
                  index = None,subindex = None,
                  **variables
                  ):
        """
        creates an ellipsoid region
            ellipsoid(x,y,z,a,b,c [,name=None,beadtype=None])
        """
        # object creation
        typ = "ellipsoid"
        self.counter["all"] += 1
        self.counter[typ] +=1
        if index is None: index = self.counter["all"]
        if subindex is None: subindex = self.counter[typ]
        E = Ellipsoid((self.counter["all"],self.counter["ellipsoid"]),
                      index=index,subindex=subindex,**variables)
        if (name != None) and (name != ""): E.name = name
        if (beadtype != None): E.beadtype = beadtype
        # feed USER fields
        E.USER.ID = "$"+E.name
        E.USER.args = [x,y,z,a,b,c]
        E.USER.beadtype = E.beadtype
        E.USER.side = E.sidearg(side)
        E.USER.move = E.movearg(move)
        if fake:
            self.counter["all"] -= 1
            self.counter[typ] -= 1
            return E
        else:
            self.objects[name] = E
            self.nobjects += 1
            return None

    def get(self,name):
        """ returns the object """
        if name in self.objects:
            return self.objects[name]
        else:
            raise ValueError('the object "%s" does not exist, use list()' % name)

    def __getattr__(self,key):
        """ get attribute override """
        return self.get(key)

    def __len__(self):
        """ len method """
        return len(self.objects)


    def names(self):
        """ return the names of objects sorted as index """
        namesunsorted=namessorted=list(self.objects.keys())
        nobj = len(namesunsorted)
        for iobj in range(nobj):
            namessorted[self.objects[namesunsorted[iobj]].index-1] = namesunsorted[iobj]
        return namessorted

    def count(self):
        """ count objects by type """
        typlist = []
        for  o in self.names():
            if isinstance(self.objects[o].beadtype,list):
                typlist += self.objects[o].beadtype
            else:
                typlist.append(self.objects[o].beadtype)
        utypes = list(set(typlist))
        c = []
        for t in utypes:
            c.append((t,typlist.count(t)))
        return c

    def delete(self,name):
        """ delete object """
        if name in self.objects:
            del self.objects[name]
            self.nobjects -= 1
        else:
            raise ValueError("%d is not a valid name (use list()) to list valid objects" % name)

# %% debug section - generic code to test methods (press F5)
# ===================================================
# main()
# ===================================================
# for debugging purposes (code called as a script)
# the code is called from here
# ===================================================
if __name__ == '__main__':
    # early example
    a=region(name="region A")
    b=region(name="region B")
    c = [a,b]
    # step 1
    R = region(name="my region")
    R.ellipsoid(0, 0, 0, 1, 1, 1,name="E1",toto=3)
    R
    repr(R.E1)
    R.E1.VARIABLES.a=1
    R.E1.VARIABLES.b=2
    R.E1.VARIABLES.c="(${a},${b},100)"
    R.E1.VARIABLES.d = '"%s%s" %("test",${c}) # note that test could be replaced by any function'
    R.E1
    code1 = R.E1.do()
    print(code1)
    # step 2
    R.ellipsoid(0,0,0,1,1,1,name="E2",side="out",move=["left","${up}*3",None],up=0.1)
    R.E2.VARIABLES.left = '"swiggle(%s,%s,%s)"%(${a},${b},${c})'
    R.E2.VARIABLES.a="${b}-5"
    R.E2.VARIABLES.b=5
    R.E2.VARIABLES.c=100
    code2 = R.E2.do()
    print(R)
    repr(R.E2)
    print(code2)
    print(R.names())
    R.list()