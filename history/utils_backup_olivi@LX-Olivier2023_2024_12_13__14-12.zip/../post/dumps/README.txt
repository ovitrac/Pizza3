% DUMP FILES included in workshop 1

Due to space restriction only preprocessed frames are included. The original source file was >9 GB.

├── dumps
│   ├── hertz
│   |   ├── <source file not included>  # source = dump.ulsphBulk_hertzBoundary_referenceParameterExponent+1_with1SuspendedParticle    
│   │   └── PREFETCH_dump.ulsphBulk_hertzBoundary_referenceParameterExponent+1_with1SuspendedParticle
│   │       ├── TIMESTEP_000000000.mat
│   │       ├── TIMESTEP_001000000.mat
│   │       ├── TIMESTEP_002000000.mat
│   │       ├── TIMESTEP_003300000.mat
│   │       ├── TIMESTEP_004400000.mat
│   │       ├── TIMESTEP_005000000.mat
│   │       ├── TIMESTEP_006000000.mat
│   │       ├── TIMESTEP_007000000.mat
│   │       └── TIMESTEP_008000000.mat


INRAE\Olivier Vitrac - 2023-08-27
