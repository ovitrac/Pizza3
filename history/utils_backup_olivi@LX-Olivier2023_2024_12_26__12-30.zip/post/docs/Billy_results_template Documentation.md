Bonjour Martin,

Je ne t'ai pas répondu tout de suite (i) parce que nous déposions TWINLOOP en coordination (7 M€) et d'autres projets la semaine dernière sur l'appel Alimen et (ii) parce que la question posée est associée à un problème assez bien décrit dans la littérature et encore non résolu.

### Problèmes associés au Mercure

Le mercure, comme les autres métaux lourds, doit être contrôlé dans les aliments. Voici un aperçu des problèmes rencontrés :

- **Propriétés physiques et chimiques** : Le mercure élémentaire (Hg⁰) est un métal très lourd (13,534 kg/m³), liquide à température ambiante (Tm = -38,8°C), et volatile, avec une grande tension de surface. La combinaison de ces propriétés donne une longueur capillaire de 1,9 mm (les gouttes s'écrasent sous leur propre poids pour former des flaques au-delà de cette longueur dans l'air). Le mercure a deux états d'oxydation : +1 (mercureux) et +2 (mercurique).
  
- **Immiscibilité et volatilisation** : En raison de son immiscibilité dans la plupart des simulants, tout spiking conduit à une très grande fugacité du mercure sous toutes ses formes (y compris CH₃Hg⁺ et (CH₃)₂Hg). Cela entraîne l'adsorption sur tout matériau et la volatilisation.

Voici quelques articles de référence rapportant ce problème :
- [Article 1](https://www.sciencedirect.com/science/article/abs/pii/S0308814604007162?via%3Dihub)
- [Article 2](https://pubs.acs.org/doi/abs/10.1021/ac00264a029)
- [Article 3](https://pubs.acs.org/doi/abs/10.1021/ac60314a055)
- [Article 4](https://www.sciencedirect.com/science/article/abs/pii/S0048969704005315?via%3Dihub)
- [Article 5](https://pubs.acs.org/doi/abs/10.1021/ac60337a002)
- [Article 6](https://pubs.acs.org/doi/abs/10.1021/ac50037a042)
- [Article 7](https://www.sciencedirect.com/science/article/abs/pii/S0003267001824934?via%3Dihub)
- [Article 8](https://pubs.rsc.org/en/content/articlelanding/1996/an/an9962100173)
- [Article 9](https://link.springer.com/article/10.1007/BF00331410)
- [Article 10](https://www.tandfonline.com/doi/abs/10.1080/03067319908032659)
- [Article 11](https://onlinelibrary.wiley.com/doi/10.1002/gch2.201900061)

### Problèmes Spécifiques en Analyse

- **Perte par volatilisation** : Toute méthode d’analyse avec un espace de tête important entraîne une perte par volatilisation, en particulier pour Hg⁰, CH₃Hg⁺.
- **Adsorption** : Les récipients en borosilicate, verre ou plastique entraînent une adsorption significative du mercure. Notez la différence entre adsorption (adsorption de mercure sur les parois) et absorption (absorption dans les matériaux dissous uniquement si l'eau peut aussi diffuser).
- **Précipitation et changements d'oxydation** : Le mercure peut précipiter en présence d’autres molécules organiques. De plus, le nombre d’oxydation peut changer au cours de l’essai, compliquant encore les analyses.

### Recommandations

Étant donné que ce problème est bien connu, je suggère les approches suivantes :
1. **Répétition des tests** : Effectuer des tests avec un espace de tête minimisé et utiliser un récipient résistant à l'absorption du mercure (comme ceux revêtus de Téflon ou de silice amorphe).
2. **Revue de littérature** : Inclure une revue exhaustive de la littérature pour documenter les problèmes et les solutions possibles (les articles fournis peuvent servir de base).

### Contribution du LNE

@Mai : Complète ma réponse en donnant ce que peut faire le LNE pour ce problème compliqué d'interactions du mercure.

---

En espérant que ces informations vous seront utiles. N'hésitez pas à nous contacter pour toute question supplémentaire.

Bien cordialement,

Olivier